package teste.caixa.branca;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class User {

    // Variáveis de classe
    public String nome = "";
    public boolean result = false;

    /**
     * Método responsável por estabelecer a conexão com o banco de dados.
     * 
     * @return Objeto Connection se a conexão for bem-sucedida, caso contrário, retorna null.
     */
    public Connection conectarBD() {
        Connection conexao = null;

        // Parâmetros de conexão
        String driver = "com.mysql.cj.jdbc.Driver";  // Driver JDBC para MySQL
        String url = "jdbc:mysql://localhost:3306/test?serverTimezone=UTC";  // URL de conexão com o banco
        String user = "root";  // Usuário 'root'
        String password = "260805";  // Senha '260805' (alterar conforme sua configuração)

        try {
            // Carregar o driver JDBC
            Class.forName(driver);

            // Estabelecer a conexão
            conexao = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            // Exibe a mensagem de erro caso a conexão falhe
            System.out.println("Erro ao conectar ao banco de dados: " + e.getMessage());
        }
        return conexao;
    }

    /**
     * Método responsável por verificar as credenciais de login e senha de um usuário.
     * 
     * @param login Login do usuário.
     * @param senha Senha do usuário.
     * @return true se o usuário for autenticado, caso contrário false.
     */
    public boolean verificarUsuario(String login, String senha) {
        String sql = "SELECT nome FROM usuarios WHERE login = ? AND senha = ?";  // SQL com parâmetros

        try (Connection conn = conectarBD();  // Conecta ao banco
             PreparedStatement pst = conn.prepareStatement(sql)) {  // Prepara a consulta

            // Substitui os parâmetros da consulta de forma segura
            pst.setString(1, login);  // Substitui o primeiro parâmetro (login)
            pst.setString(2, senha);  // Substitui o segundo parâmetro (senha)

            try (ResultSet rs = pst.executeQuery()) {  // Executa a consulta e armazena o resultado
                // Verifica se o usuário foi encontrado
                if (rs.next()) {
                    result = true;  // Usuário autenticado com sucesso
                    nome = rs.getString("nome");  // Atribui o nome do usuário autenticado
                }
            }

        } catch (Exception e) {
            // Exibe a mensagem de erro caso haja problemas na consulta
            System.out.println("Erro ao executar a consulta: " + e.getMessage());
        }
        return result;  // Retorna se o login foi bem-sucedido ou não
    }
}
